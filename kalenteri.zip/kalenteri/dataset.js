function getEvents(){

	return [
		{
			id : 'E02',
			title : '',
			start : '29-10-2014 11:00:00',
			end : '29-10-2014 12:00:00',
			backgroundColor: '#34BB22',
			textColor : '#FFF'
		},
		{
			id : 'E01',
			title : '',
			start : '27-10-2014 10:30:00',
			end : '27-10-2014 13:00:00',
			backgroundColor: '#34BB22',
			textColor : '#FFF'
		}
		
	];
}