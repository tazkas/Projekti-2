<?php
	/*
		db.php
	*/
	define("shost", "localhost");
	define("suser", "root");
	define("spass", "");
	define("sdb", "register");
	
	// Table / View variable names
	$table_device = "device";
	$table_owner  = "owner";
	$table_category = "categories";
	$table_loan = "loan";
	$table_location = "location";
	
	$conn = mysqli_connect(shost, suser, spass, sdb);
	
	if(!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
?>


function getEvents(){

	return [
	<?php
		echo 
		"	{
				id : 'E02',
				title : '',
				start : '29-10-2014 11:00:00',
				end : '29-10-2014 12:00:00',
				backgroundColor: '#ff0000',
				textColor : '#ffffff'
			},
			{
				id : 'E01',
				title : '',
				start : '27-10-2014 10:30:00',
				end : '27-10-2014 13:00:00',
				backgroundColor: '#ff0000',
				textColor : '#ffffff'
			},
		";
	
		$query = "SELECT id, loan_date, end_date, type FROM $table_loan";
		
		if ($result = mysqli_query($conn, $query))
		{
			while($row = mysqli_fetch_assoc($result))
			{
				if ($row["type"] == "lainaus")
				{
					$id = $row["id"];
					$loan_date = new DateTime($row["loan_date"]);
					$loan_date->format('d-m-Y H:i:s');
					$end_date = new DateTime($row["end_date"]);
					$end_date->format('d-m-Y H:i:s');
					echo "
					{
						id : $id,
						title : '',
						start : '27-10-2014 10:30:00',
						end : '27-10-2014 10:30:00',
						backgroundColor : '#ff0000',
						textColor : '#FFF'
					},
					";
				}
				else if ($row["type"] == "varaus")
				{
					$id = $row["id"];
					$loan_date = new DateTime($row["loan_date"]);
					$loan_date->format('d-m-Y H:i:s');
					$end_date = new DateTime($row["end_date"]);
					$end_date->format('d-m-Y H:i:s');
					echo "
					{
						id : '$id',
						title : '',
						start : '$loan_date',
						end : '$end_date',
						backgroundColor : '#ffff00',
						textColor : '#FFF'
					},
					";
				}
			}
		}
		else
			print_r(mysqli_error($conn));
		?>
	];	
}