<?php

	/*
		functions.php
		
		All external reusable functions are placed here.
		
	*/
	
	// Upload function used to upload files to specified folders.
	// Returns true if upload succeeds, false otherwise
	function upload($folder, $name){

		$target_file = "images/" . $folder . "/" . basename($_FILES[$name]["name"]);
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

		// Check if image file is a actual image or fake image
		// Some images cannot be uploaded:
		// 			For some reason the $_FILES[$name]["tmp_name"] is empty.
		if(!empty($_FILES[$name]["tmp_name"])){
			$check = getimagesize($_FILES[$name]["tmp_name"]);
		    if($check !== false) {
		        $uploadOk = 1;
		    } else {
		        $uploadOk = 0;
		    }

		    // Allow certain image formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "JPG")
			    $uploadOk = 0;

			if ($uploadOk == 0) {
	    		echo "ERROR: incorrect filetype";
	    		return false;
			// if everything is ok, try to upload file
			} else {
			    if (move_uploaded_file($_FILES[$name]["tmp_name"], $target_file)) {
			        // File uploaded successfully
			        return true;
			    } else {
			        // File upload failed
			        echo "ERROR: move_uploaded_file() failed";
			        return false;
			    }
			}
		}
		else {
			echo "ERROR: £_FILES[$name]['tmp_name'] is empty.";
			return false;
		}
	}


	// Format time
	// toFormat [ fin, sql, timestamp ]
	function timeFormat($time, $toFormat, $seconds=false){
		if(strtotime($time) !== false) $time = strtotime($time);
		switch($toFormat){
			case "fin":
				if($seconds) $time = date("d.m.Y H:i:s", $time);
				else $time = date("d.m.Y H:i", $time);
				break;
			case "sql":
				if($seconds) $time = date("Y-m-d H:i:s", $time);
				else $time = date("Y-m-d H:i", $time);
				break;
			case "timestamp":
				$time = strtotime($time);
				break;
			default:
				$time = "Invalid argument.";
				break;
		}
		return $time;
	}

	// Generates a hash based on a random number and 
	// microtime unix epoch timestamp
	function generateHash(){
		return (int)mt_rand() . (int)round(microtime(true));
	}
	
	// Check if devices available, returns bool status and string message
	function ReservationOK($conn, $model, $amount, $ownerID, $start, $end){
		echo "FUNCTION: ReservationOK\nMODEL = $model\nOWNER = $ownerID\n";
		$result = ["status" => false, "message" => "ERROR: Query failed.", "eans" => array()];
			
		$query1 = "select * from loan where 
				device_model = '$model' and 
				owner_id = '$ownerID' and 
				loan_type = 'reservation' and 
				end_date >= '$start' and 
				loan_date <= '$end' and 
				return_date is null"; // this line is a test line
				
		$query2 = "SELECT count(model) as dcount from device where owner_id = '$ownerID' and model = '$model'";
		
		// First we get the total amount of devices the owner owns, then we 
		// check if any of them are available
		if($q2_result = mysqli_query($conn, $query2)){
			$row = mysqli_fetch_assoc($q2_result);
			$total_amount = intval($row["dcount"]);
			$eans = array();
			
			if($q1_result = mysqli_query($conn, $query1)){
				
				print_r(mysqli_num_rows($q1_result));
				// check if there are enough devices available at that time
				// num_rows == number of loaned devices
				if (mysqli_num_rows($q1_result) == 0){
					echo "NUMROWS = 0\n";
					$query4 = "SELECT device_ean FROM device WHERE model='$model' AND owner_id='$ownerID'";
					$eansArr = array();
					if ($q4_result = mysqli_query($conn, $query4)){
						while($row = mysqli_fetch_assoc($q4_result)){
								echo "ROW:";
								print_r($row);
								$eansArr[] = $row["device_ean"];
								if(count($eansArr) == $amount) break;
						}
						$result["eans"] = $eansArr;
						echo "\nEANS ARR:\n";
						print_r($eansArr);
						$result["status"] = true;
					}else echo mysqli_error($conn);
				}

				else if($total_amount - mysqli_num_rows($q1_result) >= $amount && mysqli_num_rows($q1_result) > 0 ) {
					echo "NUM ROWS > 0\n";
					$result["status"] = true;
					while ($row = mysqli_fetch_assoc($q1_result)){
						
						$temp = explode("<br/>", $row["info"]);
						echo "\nROW INFO\n";
						print_r($temp);
						for ($i = 0; $i < count($temp) - 1; $i++)
							$eans[$temp[$i]] = true;
					}
					echo "EANS AFTER PARSING INFO:\n";
					print_r($eans);
					$query3 = "SELECT device_ean FROM device WHERE model ='$model' AND owner_id='$ownerID'";
					$eansArr = array();
					if ($q3_result = mysqli_query($conn, $query3)){
						while($row = mysqli_fetch_assoc($q3_result)){
							if(!isset($eans[$row["device_ean"]]))
								$eansArr[] = $row["device_ean"];
							if(count($eansArr) == $amount) break;
						}
						$result["eans"] = $eansArr;
						print_r($eansArr);
					}else echo mysqli_error($conn);
						
				
				} else {
					$result["message"] = "Varausta ei hyväksytty, tarpeeksi laitteita ei vapaana.";
				}
				
			}
		}
				
		return $result;
	}
	
	
	
	
	
	
	
	
	
	
?>