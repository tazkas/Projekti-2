<?php

	/*

		lainat.php
	
		This file displays and handles all loans.

	*/

	require_once "templates.php";
	require_once "db.php";
	require_once "functions.php";


	executeHeader("Laiterekisteri", "lainat", "container");

	// These variables have all the html code for the tables.
	$t1_1 = "<div class='container'>
	<h2>Lainat</h2>
	<table id='T1' class='table table-hover'>
		<thead>
			<tr>
				<th>Käyttäjä</th>
				<th>Lainauksen päivämäärä</th>
				<th>Lainauksen päättymispäivä</th>
				<th>Laite</th>
				<th>Kommentit</th>
			</tr>
		</thead>
		<tbody>";
		
	$t1_2 =	"</tbody></table></div>";
	
	$t2_1 = "<div class='container'>
	<h2>Varaukset</h2>
	<table id='T2' class='table table-hover'>
		<thead>
			<tr>
				<th>Käyttäjä</th>
				<th>Varauksen päivämäärä</th>
				<th>Lainauksen aloituspäivä</th>
				<th>Lainauksen päättymispäivä</th>
				<th>Laite</th>
				<th>Kommentit</th>
			</tr>
		</thead>
		<tbody>";
		
	$t2_2 = "</tbody></table></div>";
	
	//SQL query for all loans & reservations
	$query = "SELECT loan.type, loan.username,loan.reservation_date ,loan.loan_date, loan.end_date, loan.info, loan.device_model from loan";
	
	$result = mysqli_query($conn, $query);

	$reservations = array();
	$loans = array();

	//error message incase error occurs during SQL query
	if (!$result)
		echo "Kysely epaonnistui " . mysqli_error($conn);
	
	else
	{	//read database data and echo reservation infromation on the website
		while ($row = mysqli_fetch_assoc($result))
		{			
			// Store reservations to be echoed later
			if ($row["type"] == "reservation"){
				$reservations[] = "<tr class='active'><td>$row[username]</td>" .
				"<td>" . timeFormat($row["reservation_date"], "fin") . "</td><td>" . timeFormat($row["loan_date"], "fin") . "</td>" .
				"<td>" . timeFormat($row["end_date"], "fin") . "</td><td>$row[device_model]</td>" .
				"<td>$row[info]</td></tr>";
			}

			// Echo loans directly
			else{
				$loans[] = "<tr><td>$row[username]</td><td>" . timeFormat($row["loan_date"], "fin") . 
				"</td><td>" . timeFormat($row["end_date"], "fin") . "</td><td>$row[device_model]</td><td>$row[info]</td></tr>";
			}
		}
	}
	
	// Echo loans and reservations if there are any,
	// echo infomessage otherwise
	if(!empty($loans)){
		echo $t1_1;
		foreach($loans as $l) echo $l;
		echo $t1_2;
	} else echo "<h2>Lainat</h2><br/><div class='well'>Ei lainassa olevia laitteita</div><br/><br/>";
	
	if(!empty($reservations)){

		echo $t2_1;
		foreach($reservations as $r) echo $r;
		echo $t2_2;
	} else echo "<h2>Varaukset</h2><br/><div class='well'>Ei alustavia varauksia</div><br/><br/>";

	executeFooter(); 
	
?>