<?php

	/*
		editdevice.php
	*/

	require_once "db.php";

	if(isset($_REQUEST["model"])){

		$inputs = "";
		$model = $_REQUEST["model"];
		$query = "select * from $table_device where model = '$model'";
		if($result = mysqli_query($conn, $query)){
			$row = mysqli_fetch_assoc($result);
			$inputs .= "<label>Laitteen nimi</label><input class='form-control' type='text' value='$row[model]' placeholder='Esim. iPhone 7' name='edit-device-model'><br/>\n";
			$inputs .= "<label>Laitteen tyyppi</label><input class='form-control' type='text' value='$row[device_type]' placeholder='Esim. älypuhelin' name='edit-device-type'><br/>\n";
			$inputs .= "<label>Laitteen kuvaus</label><textarea rows='5' class='form-control' style='resize:none;' placeholder='Esim. laitteen speksit' name='edit-device-description'>$row[description]</textarea><br/>\n";

			$category_options = "";
			$query = "select id, name from $table_category";
			if($result = mysqli_query($conn,$query)){
				while($row2 = mysqli_fetch_assoc($result)){
					if($row2["id"] == $row["category"]) $category_options .= "<option value='$row2[id]' selected>$row2[name]</option>\n";
					else $category_options .= "<option value='$row2[id]'>$row2[name]</option>\n";
				}
			}
			$inputs .= "<label>Laitteen kategoria</label><select class='form-control' name='edit-device-category'>$category_options</select><br/>\n";


			$locations = "";
			$query = "select id, address from location";
			if($result = mysqli_query($conn, $query)){
				while($row3 = mysqli_fetch_assoc($result)){
					if($row3["id"] == $row["location"]) $locations .= "<option value='$row3[id]' selected>$row3[address]</option>\n";
					else $locations .= "<option value='$row3[id]'>$row3[address]</option>\n";
				}
			}
			$inputs .= "<label>(((Laitteen sijainti)))</label><select class='form-control' name='edit-device-location'>$locations</select><br/><br/>\n";

			$inputs .= "<input class='btn btn-success' type='submit' value='Tallenna muutokset' name='edit-device-submit'><br/>\n";
			


			echo $inputs;
		}


	}

?>